package es.ulpgc.spotify.downloader;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.sql.*;
import java.util.*;


public class Main {

    public static void main(String[] args) throws Exception {
        String dbPath = "C:/Users/jesus/IdeaProjects/spotify (1)/spotify/database.db";

        try(Connection conn = connect(dbPath)) {
            Statement statement = conn.createStatement();
            statement.execute("DROP TABLE artists");
            statement.execute("DROP TABLE albums");
            statement.execute("DROP TABLE tracks");
            statement.execute("CREATE TABLE IF NOT EXISTS artists (id TEXT PRIMARY KEY, name TEXT NOT NULL, popularity INTEGER, type Text)");
            statement.execute("CREATE TABLE IF NOT EXISTS albums (id TEXT PRIMARY KEY, title TEXT NOT NULL, release_date TEXT, release_date_precision TEXT, type TEXT)");
            statement.execute("CREATE TABLE IF NOT EXISTS tracks (id TEXT PRIMARY KEY, title TEXT NOT NULL, duration INTEGER, explicit BOOLEAN)");

            PreparedStatement ps_albums = conn.prepareStatement("INSERT INTO albums VAlUES(?, ?, ?, ?, ?);");
            PreparedStatement ps_tracks = conn.prepareStatement("INSERT INTO tracks VAlUES(?, ?, ?, ?);");
            PreparedStatement ps_artist = conn.prepareStatement("INSERT INTO artists VAlUES(?, ?, ?, ?);");

            Scanner teclado = new Scanner(System.in).useDelimiter("\n");
            List<String> list_artist = new ArrayList<>();

            System.out.println("Si desea descargar 5 artistas predeterminados inserte 1, si desea descargar un artista personalmente pulse 2: ");
            int input = Integer.parseInt(teclado.next());
            if (input == 1){
                list_artist.add("52iwsT98xCoGgiGntTiR7K");
                list_artist.add("2T3D6kBjXg7ofm7GXBaDQU");
                list_artist.add("0YareylyDe4JjJMplBzpOB");
                list_artist.add("1nwjHzOUQZsNYX8xoWiGVC");
                list_artist.add("4x3Vb1a9yggcqEuRljiLeB");
                System.out.println("Espere, se están descargando los datos en la base de datos.");
            } else if (input == 2){
                System.out.println("Añade la id de un artista\n (Ejemplo: Quevedo = 52iwsT98xCoGgiGntTiR7K): ");
                String id_artist_add = teclado.next();
                list_artist.add(id_artist_add);
                System.out.println("Espera, se están descargando los datos en la base de datos.");
            } else {
                System.out.println("Ha seleccionado un valor erróneo. Repita el programa.");
                System.exit(0);
            }

            SpotifyAccessor accessor = new SpotifyAccessor();

            for (String artits_id : list_artist){
                String json_albums = accessor.get("/artists/" + artits_id + "/albums", Map.of());
                JsonObject jsonObject = new Gson().fromJson(json_albums, JsonObject.class);
                JsonArray albums = jsonObject.get("items").getAsJsonArray();
                List<String> albums_id = new ArrayList<>();

                for (JsonElement item : albums) {
                    String id = ((JsonObject)item).get("id").getAsString();
                    ps_albums.setString(1, id);
                    albums_id.add(id);
                    String name = ((JsonObject)item).get("name").getAsString();
                    ps_albums.setString(2, name);
                    String release_date = ((JsonObject)item).get("release_date").getAsString();
                    ps_albums.setString(3, release_date);
                    String release_date_precision = ((JsonObject)item).get("release_date_precision").getAsString();
                    ps_albums.setString(4, release_date_precision);
                    String type = ((JsonObject)item).get("type").getAsString();
                    ps_albums.setString(5, type);
                    ps_albums.executeUpdate();
                }

                for (String album_id: albums_id) {
                    String response_tracks = accessor.get("/albums/" + album_id + "/tracks", Map.of());
                    JsonObject jsonObject3 = new Gson().fromJson(response_tracks, JsonObject.class);
                    JsonArray items = jsonObject3.get("items").getAsJsonArray();

                    for (JsonElement item : items) {
                        String id = ((JsonObject) item).get("id").getAsString();
                        ps_tracks.setString(1, id);
                        String name = ((JsonObject) item).get("name").getAsString();
                        ps_tracks.setString(2, name);
                        String duration = ((JsonObject) item).get("duration_ms").getAsString();
                        ps_tracks.setString(3, duration);
                        String explicit = ((JsonObject) item).get("explicit").getAsString();
                        ps_tracks.setString(4, explicit);
                        ps_tracks.executeUpdate();
                    }
                }

                String response_artist = accessor.get("/artists/" + artits_id, Map.of());
                JsonObject jsonObject2 = new Gson().fromJson(response_artist, JsonObject.class);

                String id = (jsonObject2.get("id").getAsString());
                String name = (jsonObject2.get("name").getAsString());
                String popularity = (jsonObject2.get("popularity").getAsString());
                String type = (jsonObject2.get("type").getAsString());
                ps_artist.setString(1, id);
                ps_artist.setString(2, name);
                ps_artist.setString(3, popularity);
                ps_artist.setString(4, type);
                ps_artist.executeUpdate();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Connection connect(String dbPath) {
        Connection conn;
        try {
            String url = "jdbc:sqlite:" + dbPath;
            conn = DriverManager.getConnection(url);
            System.out.println("Connection to SQLite has been established.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return conn;
    }
}